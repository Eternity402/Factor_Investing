CONFIG = {
    'dir_fundamental': 'C:/Users/lyoo9/_Akros', # directory where fundamental data & index exist.
    'dir_market_data': 'C:/Users/lyoo9/_System Trading/Backend/KRX_price', # directory where market data exists.
    'dir_risk_free_rate': 'C:/Users/lyoo9/_Akros' # directory where risk free rate exists.
}