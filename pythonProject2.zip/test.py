from sirius import Sirius
from config_sirius import CONFIG

sirius = Sirius(CONFIG)

lab = sirius.factor_lab()

print(lab.get_item_for_period('ifrs_Revenue', '20121231', '20171231'))